﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Encuesta.Models;

namespace Encuesta.Controllers
{
    public class ConfiguracionController : Controller
    {
        // GET: Configuracion
        public ActionResult Index()
        {
            Encuesta.Models.CuestionarioContext db = new Models.CuestionarioContext();
            //db.S_Configuracion_Cuestionario.ToList();
            return View(db.S_Configuracion_Cuestionario.ToList ());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(S_Configuracion_Cuestionario c )
        {
            if (!ModelState.IsValid)
                return View();

            try
            {
                using (CuestionarioContext db = new CuestionarioContext())
                {
                    db.S_Configuracion_Cuestionario.Add(c);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

            }
            catch (Exception ex)
            {

                ModelState.AddModelError("", "Error al crear configuración - " + ex.Message );
                return View();
            }
            
            
        }
    }
}
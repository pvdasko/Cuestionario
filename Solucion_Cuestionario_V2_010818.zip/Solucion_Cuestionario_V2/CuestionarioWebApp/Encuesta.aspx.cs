﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Cuestionario.BusinessRuleComponent;

namespace CuestionarioWebApp
{
    public partial class Encuesta : Page
    {
        int pcorpo;
        string photel;
        string ptipo;
        int pfolio;
        private string backgroundImage;
        protected string BackgroundImage { get { return backgroundImage; } }
        private string logoImage;
        protected string LogoImage { get { return logoImage; } }


        public Cuestionario.BusinessRuleComponent.Cuestionario objCuestionario;
        protected void Page_Load(object sender, EventArgs e)
        {            
            if (!IsPostBack)
            {               
                cargaBackground();
                validaHuesped();

            }
            
            Page.RegisterRedirectOnSessionEndScript();

        }


        public void cargaBackground()
        {
            string backgroundImage = string.Empty;

            //Logic to determin imageURL goes here
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            Session["scorpo"] = pcorpo;
            Session["shotel"] = photel;
            Session["sfolio"] = pfolio;

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                var pag = context.C_Tipos_Cuestionario.Where(m => m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario).FirstOrDefault();
                this.backgroundImage = pag.Background_Cuestionario;
                this.logoImage = pag.Logo_Cuestionario;
            }


        }


        private void validaHuesped()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            Session["scorpo"] = pcorpo;
            Session["shotel"] = photel;
            Session["sfolio"] = pfolio;

            using (CuestionarioEntities context = new CuestionarioEntities())
            {

                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var pag = context.C_Tipos_Cuestionario.Where(m => m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario).FirstOrDefault();
                Session["sweb"] = pag.Url_Reinicio_Encuesta.ToString();

                var huesped = (from h in context.O_Cuestionarios
                               where h.Corporativo == pcorpo && h.Hotel == photel && h.Id == pfolio
                               select new
                               {
                                   h
                               });

                if (huesped.Count() > 0)
                {
                    if (!validaEncuesta() && !validaVigencia())
                    {
                        guardaClick();
                        cargaEncuesta();
                    }

                }
                else
                {

                    Response.Redirect("Empty.aspx?paction=2");

                }


            }

        }

        private bool validaEncuesta()
        {

            bool valida = true;

            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Corporativo == pcorpo && x.Hotel == photel && x.Id == pfolio).FirstOrDefault();

                if (cuestionario.Fecha_Contestado  == null)
                {

                    valida = false;

                }
                else
                {
                    Response.Redirect("Empty.aspx?paction=1");


                }



            }

            return valida;

        }

        private bool validaVigencia()
        {

            bool valida = true;

            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                if (cuestionario.Valido_Hasta == null || cuestionario.Valido_Hasta > DateTime.Now)
                {

                    valida = false;

                }
                else
                {
                    Response.Redirect("Empty.aspx?paction=5");


                }



            }

            return valida;

        }

        private void cargaEncuesta()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);
            ptipo = "";

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                ptipo = tipoCuestionario.Tipo_Cuestionario;
            }


            this.objCuestionario = new Cuestionario.BusinessRuleComponent.Cuestionario();
            objCuestionario.Corporativo = pcorpo;
            objCuestionario.Hotel = photel;
            objCuestionario.Tipo_Cuestionario = ptipo;


            this.RprEncuesta.DataSource = objCuestionario.getCuestionario();
            this.RprEncuesta.DataBind();

        }


        protected string encuestaHeader()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse (Request.QueryString["id"]);
            string pdesc;
            string pdescing;
            string ptxt;
            string ptxting;
            DataTable   datosCliente = new DataTable ();

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var textSupIng = (from c in context.C_Tipos_Cuestionario
                                  where c.Corporativo == pcorpo && c.Hotel == photel && c.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario
                                  select new
                                  {
                                      c

                                  }).SingleOrDefault();

                pdesc = textSupIng.c.Descripcion;
                pdescing = textSupIng.c.Descripcion_Ingles;
                ptxt = textSupIng.c.Texto_Superior;
                ptxting = textSupIng.c.Texto_Superior_Ingles;


            }

            this.objCuestionario = new Cuestionario.BusinessRuleComponent.Cuestionario();
            objCuestionario.Corporativo = pcorpo;
            objCuestionario.Hotel = photel;
            objCuestionario.Folio = pfolio.ToString ();

            datosCliente  = objCuestionario.getCuestionarioCliente ();
           
            return this.objCuestionario.construyeHeader(datosCliente , pdesc, pdescing, ptxt, ptxting);
        }

        protected string encuestaItem(object datos)
        {
            string pidioma;
            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                pidioma = tipoCuestionario.Idioma;
            }
            return this.objCuestionario.construyeItem(datos, pidioma);
        }



        protected void btnSend_Click(object sender, EventArgs e)
        {
            string body;
            body = construyeCuerpo();
            guardaFecha();
            enviaCorreo(body);
            Response.Redirect("Empty.aspx?paction=3");

        }


        private string construyeCuerpo()
        {


            StringBuilder sb = new StringBuilder();
            DataTable dtable = new DataTable();
            DataTable dtableCliente = new DataTable();

            string dnopregunta;
            string dtipopregunta;
            string dpregunta;
            string dpreguntaing;
            int dcalifmax;
            string drespuesta;
            string drespuestaing;
            string dnorespuesta;
            bool drespabierta;
            int maximo;
            string dnorespuestaHuesped;
            string dtexto;
            string dcalificacion;
            string pdesc;
            string pdescing;
            string ptxt;
            string ptxting;
            int id;
            string didioma;
            int sumcalif;
            string pheader;
            id = int.Parse(HttpContext.Current.Session["sfolio"].ToString());

            using (CuestionarioEntities context = new CuestionarioEntities())
            {


                Cuestionario.BusinessRuleComponent.Cuestionario objCuestionarioResp = new Cuestionario.BusinessRuleComponent.Cuestionario();

                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == id).FirstOrDefault();

                didioma = tipoCuestionario.Idioma;

                objCuestionarioResp.Corporativo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
                objCuestionarioResp.Hotel = HttpContext.Current.Session["shotel"].ToString();
                objCuestionarioResp.Tipo_Cuestionario = tipoCuestionario.Tipo_Cuestionario;
                objCuestionarioResp.Folio = HttpContext.Current.Session["sfolio"].ToString();

                dtable = objCuestionarioResp.getCuestionarioResp();
                dtableCliente = objCuestionarioResp.getCuestionarioCliente(); 

                var textSupIng = (from c in context.C_Tipos_Cuestionario
                                  where c.Corporativo == objCuestionarioResp.Corporativo && c.Hotel == objCuestionarioResp.Hotel && c.Tipo_Cuestionario == objCuestionarioResp.Tipo_Cuestionario
                                  select new
                                  {
                                      c

                                  }).SingleOrDefault();

                pdesc = textSupIng.c.Descripcion;
                pdescing = textSupIng.c.Descripcion_Ingles;
                ptxt = textSupIng.c.Texto_Superior;
                ptxting = textSupIng.c.Texto_Superior_Ingles;


            }
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><body style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\">");
           
            if (didioma == "E")
            {

                pheader = "<strong>Id Encuesta: </strong>" + HttpContext.Current.Session["sfolio"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Nombre: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Nombre"].ToString();
                pheader = pheader + " ";
                pheader = pheader + dtableCliente.Rows[0]["Apellido"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Estancia: </strong>";
                pheader = pheader + DateTime.Parse(dtableCliente.Rows[0]["Llegada"].ToString()).ToString("dd/MM/yyyy");
                pheader = pheader + "<strong> al </strong>";
                pheader = pheader +  DateTime.Parse(dtableCliente.Rows[0]["Salida"].ToString()).ToString("dd/MM/yyyy");
                pheader = pheader + "<strong> Habitación: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Habitacion"].ToString();
                pheader = pheader + "<strong> Tipo: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["TipoHabitacion"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Id ERP: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["IdERP"].ToString();
                pheader = pheader + "<strong> Id CRM: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["IdCRM"].ToString();
                pheader = pheader + "<strong>  Agencia: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Agencia"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Pdv: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["CodigoPDV"].ToString();
                pheader = pheader + "<strong> Pais: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Pais"].ToString();
                pheader = pheader + "<strong> Empresa: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Empresa"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong> Correo: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Email"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + " <strong>Telefono: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Telefono"].ToString();
                pheader = pheader + "</br></br><strong>Respuestas Cuestionario</strong> </br>";
                sb.Append("<div align=\"left\">" + pheader + "</div>");
            }
            else
            {
                pheader = "<strong>Id Survey: </strong>" + HttpContext.Current.Session["sfolio"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Name: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Nombre"].ToString();
                pheader = pheader + " ";
                pheader = pheader + dtableCliente.Rows[0]["Apellido"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Stay: </strong>";
                pheader = pheader + DateTime.Parse(dtableCliente.Rows[0]["Llegada"].ToString()).ToString("dd/MM/yyyy");
                pheader = pheader + "<strong> at </strong>";
                pheader = pheader + DateTime.Parse(dtableCliente.Rows[0]["Salida"].ToString()).ToString("dd/MM/yyyy");
                pheader = pheader + "<strong> Room: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Habitacion"].ToString();
                pheader = pheader + "<strong> Type: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["TipoHabitacion"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Id ERP: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["IdERP"].ToString();
                pheader = pheader + "<strong> Id CRM: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["IdCRM"].ToString();
                pheader = pheader + "<strong>  Agency: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Agencia"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong>Pos: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["CodigoPDV"].ToString();
                pheader = pheader + "<strong> Country: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Pais"].ToString();
                pheader = pheader + "<strong> Company: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Empresa"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + "<strong> Email: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Email"].ToString();
                pheader = pheader + "</br>";
                pheader = pheader + " <strong>Phone: </strong>";
                pheader = pheader + dtableCliente.Rows[0]["Telefono"].ToString();
                pheader = pheader + "</br></br><strong>Survey answers</strong> </br>";
                sb.Append("<div><strong align=\"justify\">" + ptxting + "</strong></div>");
            }
            sb.Append("<br><br>");

            foreach (DataRow info in dtable.Rows)
            {
                sumcalif =0;
                dnopregunta = info["No Pregunta"].ToString();
                dtipopregunta = info["Tipo Pregunta"].ToString();
                dpregunta = info["Pregunta"].ToString();
                dpreguntaing = info["Pregunta Ingles"].ToString();
                dcalifmax = int.Parse(info["Calificacion Maxima"].ToString());
                drespuesta = info["Respuesta"].ToString();
                drespuestaing = info["Respuesta Ingles"].ToString();
                dnorespuesta = info["No Respuesta"].ToString();
                drespabierta = bool.Parse(info["Respuesta Abierta"].ToString());
                maximo = int.Parse(info["Maximo"].ToString());
                dnorespuestaHuesped = info["RespuestaHuesped"].ToString();
                dtexto = info["Texto"].ToString();
                dcalificacion = info["Calificacion"].ToString();

                if (dnopregunta == "1")
                    sb.Append("<table style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\">");


                if (dnorespuesta == "1")
                {
                    if (didioma == "E")
                    { sb.Append("<tr><td><span><strong >" + dpregunta + "</strong></span></td></tr>"); }
                    else
                    { sb.Append("<tr><td><span><strong >" + dpreguntaing + "</strong></span></td></tr>"); }
                    sb.Append("<tr><td></td></tr> ");
                    if (dtipopregunta == "Calif")
                    {
                        sb.Append("<tr><td>");
                        sb.Append(" <div><table style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\"><tr><th></th>");
                        for (int i = 1; i <= dcalifmax; i++)
                        {
                            sb.Append("<th align=\"center\">");
                            sb.Append(i.ToString());
                            sb.Append("</th>");
                        }
                        sb.Append("<th>");
                        sb.Append("N/A");
                        sb.Append("</th>");
                        sb.Append("</tr>");

                    }
                }



                switch (dtipopregunta)
                {

                    case "Abier":
                        sb.Append("<tr>");
                        sb.Append("<td><span>" + dtexto + "</span></td>");
                        sb.Append("</tr>");
                        sb.Append("<tr><td></td></tr> ");
                        break;

                    case "Calif":
                        sb.Append("<tr><td>");
                        if (didioma == "E")
                        { sb.Append("<span>" + drespuesta + "</span></td>"); }
                        else
                        { sb.Append("<span>" + drespuestaing + "</span></td>"); }

                        for (int j = 1; j <= dcalifmax + 1; j++)
                        {
                            sumcalif = sumcalif + int.Parse (dcalificacion);
                        }

                        for (int i = 1; i <= dcalifmax ; i++)
                        {
                            if (int.Parse(dcalificacion) == i )
                            {
                                sb.Append("<td align=\"center\">");
                                sb.Append("(X)");
                                sb.Append("</td>");
                            }
                            else
                            {
                                sb.Append("<td align=\"center\">");
                                sb.Append("(&nbsp)");
                                sb.Append("</td>");
                            }

                           
                        }

                        if (sumcalif == 0)
                        {

                            sb.Append("<td align=\"center\">");
                            sb.Append("(X)");
                            sb.Append("</td>");
                        }
                        else
                        {
                            sb.Append("<td align=\"center\">");
                            sb.Append("(&nbsp)");
                            sb.Append("</td>");
                        }

                        break;

                    case "Opcio":
                        sb.Append("<tr>");
                        if (!drespabierta)
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td>(X)&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td>(X)&nbsp<span>" + drespuestaing + "</span></td>"); }
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                if (didioma == "E")
                                { sb.Append("<td>(&nbsp)&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td>(&nbsp)&nbsp<span>" + drespuestaing + "</span></td>"); }
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        else
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td><span>" + drespuesta + " : " + dtexto + "</span></td>"); }
                                else
                                { sb.Append("<td><span>" + drespuestaing + " : " + dtexto + "</span></td>"); }
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                sb.Append("<td></td>");
                                sb.Append("<tr><td></td></tr> ");
                            }

                        }
                        sb.Append("</tr>");
                        break;

                    case "Selec":
                        sb.Append("<tr>");
                        if (!drespabierta)
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td>[X]&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td>[X]&nbsp<span>" + drespuestaing + "</span></td>"); }
                                sb.Append("</tr>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                if (didioma == "E")
                                { sb.Append("<td>[&nbsp]&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td>[&nbsp]&nbsp<span>" + drespuestaing + "</span></td>"); }
                                sb.Append("</tr>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        else
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td><span>" + drespuesta + " : " + dtexto + "</span></td>"); }
                                else
                                { sb.Append("<td><span>" + drespuestaing + " : " + dtexto + "</span></td>"); }
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                sb.Append("<td>&#160</td>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        break;
                }

                if (dtipopregunta == "Calif" && int.Parse(dnorespuesta) == maximo)
                    sb.Append("</tr></table></div>");

                if (int.Parse(dnorespuesta) == maximo)
                    sb.Append("<tr><td></td></tr> ");

            }

            sb.Append("</table> ");
            sb.Append("</body></html>");
            return sb.ToString();

        }



        private void guardaClick()
        { 
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);
            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Corporativo == pcorpo && x.Hotel== photel && x.Id == pfolio).FirstOrDefault();
                if (cuestionario == null)
                {
                    ModelState.AddModelError("", String.Format("Folio no encontrado {0} :", pfolio.ToString()));
                    return;
                }

                cuestionario.Fecha_Click =  getClientTime(DateTime.UtcNow.ToString(), "-05:00");

                if (ModelState.IsValid && cuestionario.Fecha_Click == null )
                {
                    // Save changes here
                    context.SaveChanges();

                }
            }
        }

        private void guardaFecha()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Corporativo == pcorpo && x.Hotel == photel && x.Id == pfolio).FirstOrDefault();
                if (cuestionario == null)
                {
                    ModelState.AddModelError("", String.Format("Folio no encontrado {0} :", pfolio.ToString()));
                    return;
                }

                cuestionario.Fecha_Contestado =  getClientTime(DateTime.UtcNow.ToString(), "-05:00");

                if (ModelState.IsValid)
                {
                    // Save changes here
                    context.SaveChanges();

                }
            }
        }

        private void terminaSesion()
        {
            Session.Remove("scorpo");
            Session.Remove("shotel");
            Session.Remove("stipo");
            Session.Remove("sfolio");
            string script = "window.close();";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "closewindow", script, true);

        }
        private void enviaCorreo(string pbody)
        {
            Mail correo = new Mail();
            StringBuilder sb = new StringBuilder();

            int pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
            string photel = HttpContext.Current.Session["shotel"].ToString();
            int pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var config = (from c in context.C_Tipos_Cuestionario
                              where c.Corporativo == pcorpo && c.Hotel == photel && c.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario
                              select new
                              {
                                  c

                              }).SingleOrDefault();

                var mails = (from m in context.C_Correos_Cuestionario
                             where m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario
                             select new
                             {
                                 m

                             }).ToList();

                foreach (var m in mails)
                {
                    sb.Append(m.m.Email);
                    sb.Append(";");

                }

                correo.SMTP = config.c.Servidor_SMTP;
                correo.MailFrom = config.c.Email_Saliente;
                correo.Port = int.Parse(config.c.Puerto_SMTP.ToString());
                correo.IsHTML = true;




            }
            correo.MailTo = sb.ToString().TrimEnd(';');
            correo.sendMail("Encuesta de Satisfacción", pbody);
        }


        [System.Web.Services.WebMethod]
        public static void insRespuesta(string idrespuesta, string valor)
        {


            int pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
            string photel = HttpContext.Current.Session["shotel"].ToString();
            int pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());
            int nr = 0;
            string tp = idrespuesta.Substring(0, 5);
            int ip = idrespuesta.IndexOf("_");
            int ic = idrespuesta.IndexOf("#");
            int np = int.Parse(idrespuesta.Substring(5, ip - 5));

            if (ic < 0)
            {
                nr = int.Parse(idrespuesta.Substring(ip + 1));
            }
            else
            {
                nr = int.Parse(idrespuesta.Substring(ip + 1, ic - ip - 1));
            }

            int cal = 0;
            if (ic > 0)
                cal = int.Parse(idrespuesta.Substring(ic + 1));

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                List<O_Cuestionarios_Respuestas> respuesta = PopulateResp(pcorpo, photel, np, pfolio, nr, tp);

                if (tp == "Opcio" && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                          && a.Id == pfolio
                                          && a.No_Pregunta == np);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                }
                else if ((tp == "Calif" || tp == "Abier") && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                           && a.Id == pfolio
                                          && a.No_Pregunta == np
                                          && a.No_Respuesta == nr);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                }
                else if (tp == "Selec" && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                          && a.Id == pfolio
                                          && a.No_Pregunta == np
                                          && a.No_Respuesta == nr);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                    return;
                }

                O_Cuestionarios_Respuestas resp = new O_Cuestionarios_Respuestas();
                resp.Corporativo = pcorpo;
                resp.Hotel = photel;
                resp.Id = pfolio;
                resp.No_Pregunta = np;
                resp.No_Respuesta = nr;
                resp.Calificacion = cal;
                resp.Texto = valor == "on" ? "" : valor;
                context.O_Cuestionarios_Respuestas.Add(resp);
                context.SaveChanges();

            }
        }

        [System.Web.Services.WebMethod]
        public static List<O_Cuestionarios_Respuestas> PopulateResp(int pCorpo, string pHotel, int pnp, int pfolio, int pnr, string ptp)
        {
            using (CuestionarioEntities db = new CuestionarioEntities())
            {
                if (ptp == "Opcio")
                {
                    return db.O_Cuestionarios_Respuestas.Where(a => a.Corporativo == pCorpo && a.Hotel == pHotel && a.Id == pfolio && a.No_Pregunta == pnp).ToList();
                }
                else
                {
                    return db.O_Cuestionarios_Respuestas.Where(a => a.Corporativo == pCorpo && a.Hotel == pHotel && a.Id == pfolio && a.No_Pregunta == pnp && a.No_Respuesta == pnr).ToList();
                }
            }

        }


        public static DateTime getClientTime(string date, object ClientTimeZoneoffset)
        {
            if (ClientTimeZoneoffset != null)
            {
                string Temp = ClientTimeZoneoffset.ToString().Trim();
                if (!Temp.Contains("+") && !Temp.Contains("-"))
                {
                    Temp = Temp.Insert(0, "+");
                }
                //Retrieve all system time zones available into a collection
                ReadOnlyCollection<TimeZoneInfo> timeZones = TimeZoneInfo.GetSystemTimeZones();
                DateTime startTime = DateTime.Parse(date);
                DateTime _now = DateTime.Parse(date);
                foreach (TimeZoneInfo timeZoneInfo in timeZones)
                {
                    if (timeZoneInfo.ToString().Contains(Temp))
                    {
                        TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById(timeZoneInfo.Id);
                        _now = TimeZoneInfo.ConvertTime(startTime, TimeZoneInfo.Utc, tst);
                        break;
                    }
                }
                return _now;
            }
            else
                return DateTime.Parse(date);
        }
             

    }
}
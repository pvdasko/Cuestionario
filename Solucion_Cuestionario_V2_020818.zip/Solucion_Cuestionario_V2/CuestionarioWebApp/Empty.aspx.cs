﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CuestionarioWebApp
{
    public partial class Empty : System.Web.UI.Page
    {
        int pcorpo;
        string photel;
        string ptipo;
        int  pfolio;
        string ppagreinicio;
        string paction; // 1 folio ya enviado, 2, folio inexistente, 3 encuesta enviada, 4 sesion expirada
        private string backgroundImage;
        protected string BackgroundImage { get { return backgroundImage; } }
        private string logoImage;
        protected string LogoImage { get { return logoImage; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            paction = Request.QueryString["paction"];
            ppagreinicio = HttpContext.Current.Session["sweb"].ToString();
            cargaBackground();

            this.paginaredirect.Value = "http://" + ppagreinicio  +"/";
            if (paction == "1")
            {
                lblModalTitle.Text = "Gracias por su visita";
                lblModalBody.Text = "Folio ya enviado";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                terminaSesion();

            } 
            else if (paction == "2")
            {
                lblModalTitle.Text = "Gracias por su visita";
                lblModalBody.Text = "Folio inexistente";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                terminaSesion();
            }
            else if (paction == "3")
            {
                lblModalTitle.Text = "Gracias por su visita";
                lblModalBody.Text = "Sus respuestas fueron enviadas";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                terminaSesion();
            }
            else if (paction == "4")
            {
                borraFolio();
                lblModalTitle.Text = "Su sesión expiro";
                lblModalBody.Text = "Por favor!,  vuelva a ingresar al link de la encuesta";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                terminaSesion();
               
            }
            else if (paction == "5")
            {               
                lblModalTitle.Text = "La vigencia de la encuesta ya expiro";
                lblModalBody.Text = "Gracias por su preferencia!";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                terminaSesion();

            }

            if (!IsPostBack)
            {

                Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
                Response.Cache.SetAllowResponseInBrowserHistory(false);
                Response.Cache.SetNoStore();
            }           
        }

        protected string ClientIDPageRedirect()
        {
            return this.paginaredirect.ClientID; 
        }

        protected void borraFolio()
        {
            try
            {
                pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
                photel = HttpContext.Current.Session["shotel"].ToString();
                ptipo = HttpContext.Current.Session["stipo"].ToString();
                pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());


                using (CuestionarioEntities context = new CuestionarioEntities())
                {
                    var respDel = context.O_Cuestionarios_Respuestas.Where(a =>
                                              a.Corporativo == pcorpo
                                              && a.Hotel == photel                                              
                                              && a.Id == pfolio).ToList();
                    foreach (O_Cuestionarios_Respuestas resHues in respDel)
                    {
                        context.O_Cuestionarios_Respuestas.Remove(resHues);
                    }
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                Response.Redirect("http://" + ppagreinicio  +"/"); 
            }
            
        }

        private void terminaSesion()
        {
            Session.Remove("scorpo");
            Session.Remove("shotel");
            Session.Remove("stipo");
            Session.Remove("sfolio");
            Session.Remove("paction");
            
        }

        public void cargaBackground()
        {
            try
            {
                string backgroundImage = string.Empty;

                //Logic to determin imageURL goes here
                pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
                photel = HttpContext.Current.Session["shotel"].ToString();
                pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());


                Session["scorpo"] = pcorpo;
                Session["shotel"] = photel;
                Session["sfolio"] = pfolio;

                using (CuestionarioEntities context = new CuestionarioEntities())
                {
                    var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                    var pag = context.C_Tipos_Cuestionario.Where(m => m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario).FirstOrDefault();
                    this.backgroundImage = pag.Background_Cuestionario;
                    this.logoImage = pag.Logo_Cuestionario;
                }
            }
            catch (Exception)
            {

                Response.Redirect("http://" + ppagreinicio + "/");
            }
            
            
        }
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Cuestionario.BusinessRuleComponent;

namespace CuestionarioWebApp
{
    public partial class Encuesta : System.Web.UI.Page
    {
        int pcorpo;
        string photel;
        string  ptipo;
        int pfolio;
        public Cuestionario.BusinessRuleComponent.Cuestionario objCuestionario;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                validaHuesped();

            }

            Page.RegisterRedirectOnSessionEndScript();            

        }

        

        private void validaHuesped()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];         
            pfolio = int.Parse (Request.QueryString["id"]);

            Session["scorpo"] = pcorpo;
            Session["shotel"] = photel;           
            Session["sfolio"] = pfolio;

            using (CuestionarioEntities context = new CuestionarioEntities())
            {

                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var pag = context.C_Tipos_Cuestionario.Where(m => m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario  ).FirstOrDefault();
                Session["sweb"] = pag.Url_Reinicio_Encuesta.ToString();
  
                var huesped = (from h in context.O_Cuestionarios
                               where h.Corporativo == pcorpo && h.Hotel == photel && h.Id == pfolio
                               select new
                               {
                                   h
                               });

                if (huesped.Count() > 0)
                {
                    if (!validaEncuesta() && !validaVigencia() )
                    {
                        guardaClick();
                        cargaEncuesta();
                    }
                    
                }
                else
                {

                    Response.Redirect("Empty.aspx?paction=2");  

                }


            }

        }

        private bool validaEncuesta()
        {

            bool valida = true;

            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];          
            pfolio = int.Parse (Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = (from c in context.O_Cuestionarios
                                    where c.Corporativo == pcorpo && c.Hotel == photel  && c.Id == pfolio
                                    select new
                                    {
                                        c.Fecha_Contestado
                                    });

                if (cuestionario != null )
                {

                    valida = false;

                }
                else
                {
                    Response.Redirect("Empty.aspx?paction=1");  
                  

                }



            }

            return valida;

        }

        private bool validaVigencia()
        {

            bool valida = true;

            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                if ( cuestionario.Valido_Hasta == null || cuestionario.Valido_Hasta > DateTime.Now    )
                {

                    valida = false;

                }
                else
                {
                    Response.Redirect("Empty.aspx?paction=5");


                }



            }

            return valida;

        }
       
        private void cargaEncuesta()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];            
            pfolio = int.Parse (Request.QueryString["id"]);
            ptipo = "";

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                ptipo = tipoCuestionario.Tipo_Cuestionario  ; 
            }


            this.objCuestionario = new Cuestionario.BusinessRuleComponent.Cuestionario();
            objCuestionario.Corporativo = pcorpo;
            objCuestionario.Hotel = photel;
            objCuestionario.Tipo_Cuestionario = ptipo;


            this.RprEncuesta.DataSource = objCuestionario.getCuestionario();
            this.RprEncuesta.DataBind();

        }


        protected string encuestaHeader()
        {
            pcorpo = int.Parse(Request.QueryString["corpo"]);
            photel = Request.QueryString["hotel"];
            pfolio = int.Parse(Request.QueryString["id"]);
            string pdesc;
            string pdescing;
            string ptxt ;
            string ptxting;

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var textSupIng = (from c in context.C_Tipos_Cuestionario
                                  where c.Corporativo == pcorpo && c.Hotel == photel && c.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario   
                                    select new
                                    {                                       
                                        c
                                        
                                    }).SingleOrDefault ();

                pdesc = textSupIng.c.Descripcion;
                pdescing = textSupIng.c.Descripcion_Ingles; 
                ptxt =  textSupIng.c.Texto_Superior ;
                ptxting = textSupIng.c.Texto_Superior_Ingles ;

                
            }
            return this.objCuestionario.construyeHeader(pdesc, pdescing,  ptxt, ptxting );
        }

        protected string encuestaItem(object datos)
        {
            string pidioma;
            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                pidioma = tipoCuestionario.Idioma;
            }
            return this.objCuestionario.construyeItem(datos, pidioma);
        }



        protected void btnSend_Click(object sender, EventArgs e)
        {
            string body;
            body = construyeCuerpo();
            guardaFecha();
            enviaCorreo(body);
            Response.Redirect("Empty.aspx?paction=3");  
            
        }


        private string construyeCuerpo()
        {
           

            StringBuilder sb = new StringBuilder();
            DataTable dtable = new DataTable();

            string dnopregunta;
            string dtipopregunta;
            string dpregunta;
            string dpreguntaing;
            int dcalifmax;
            string drespuesta;
            string drespuestaing;
            string dnorespuesta;
            bool drespabierta;
            int maximo;
            string dnorespuestaHuesped;
            string dtexto;
            string dcalificacion;
            string pdesc;
            string pdescing;
            string ptxt;
            string ptxting;
            int     id;
            string didioma;
          
             id =int.Parse (HttpContext.Current.Session["sfolio"].ToString());

            using (CuestionarioEntities context = new CuestionarioEntities())
            {

              
                Cuestionario.BusinessRuleComponent.Cuestionario objCuestionarioResp = new Cuestionario.BusinessRuleComponent.Cuestionario();

                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == id ).FirstOrDefault();

                didioma = tipoCuestionario.Idioma; 

                objCuestionarioResp.Corporativo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
                objCuestionarioResp.Hotel = HttpContext.Current.Session["shotel"].ToString();
                objCuestionarioResp.Tipo_Cuestionario = tipoCuestionario.Tipo_Cuestionario;
                objCuestionarioResp.Folio = HttpContext.Current.Session["sfolio"].ToString();

                dtable = objCuestionarioResp.getCuestionarioResp();


                var textSupIng = (from c in context.C_Tipos_Cuestionario 
                                  where c.Corporativo == objCuestionarioResp.Corporativo && c.Hotel == objCuestionarioResp.Hotel && c.Tipo_Cuestionario == objCuestionarioResp.Tipo_Cuestionario
                                  select new
                                  {
                                      c

                                  }).SingleOrDefault();

                pdesc = textSupIng.c.Descripcion;
                pdescing = textSupIng.c.Descripcion_Ingles; 
                ptxt = textSupIng.c.Texto_Superior;
                ptxting = textSupIng.c.Texto_Superior_Ingles;


            }
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><body style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\">");
            if (pdesc != "")
            {
                sb.Append("<strong>" + pdesc + "</strong>");
            }
            else
            {
                sb.Append("<strong>" + pdescing + "</strong>");
            }

            sb.Append("<br><br>");
            if (ptxting != "")
            {

                sb.Append("<strong>" + ptxt + "</strong>");
            }
            else
            {
                sb.Append("<strong>" + ptxting + "</strong>");
            }
            sb.Append("<br><br>");

            foreach (DataRow info in dtable.Rows)
            {

                dnopregunta = info["No Pregunta"].ToString();
                dtipopregunta = info["Tipo Pregunta"].ToString();
                dpregunta = info["Pregunta"].ToString();
                dpreguntaing = info["Pregunta Ingles"].ToString();
                dcalifmax = int.Parse(info["Calificacion Maxima"].ToString());
                drespuesta = info["Respuesta"].ToString();
                drespuestaing = info["Respuesta Ingles"].ToString();
                dnorespuesta = info["No Respuesta"].ToString();
                drespabierta = bool.Parse(info["Respuesta Abierta"].ToString());
                maximo = int.Parse(info["Maximo"].ToString());
                dnorespuestaHuesped = info["RespuestaHuesped"].ToString();
                dtexto = info["Texto"].ToString();
                dcalificacion = info["Calificacion"].ToString();

                if (dnopregunta == "1")
                    sb.Append("<table style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\">");


                if (dnorespuesta == "1")
                {
                    if (didioma == "E")
                    {sb.Append("<tr><td><span><strong >" +  dpregunta+ "</strong></span></td></tr>");}
                    else
                    {sb.Append("<tr><td><span><strong >" + dpreguntaing + "</strong></span></td></tr>");}                    
                    sb.Append("<tr><td></td></tr> ");
                    if (dtipopregunta == "Calif")
                    {
                        sb.Append("<tr><td>");
                        sb.Append(" <div><table style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #666666;\"><tr><th></th>");
                        for (int i = 1; i <= dcalifmax; i++)
                        {
                            sb.Append("<th align=\"center\">");
                            sb.Append( i.ToString());
                            sb.Append("</th>");
                        }
                        sb.Append("<th>");
                        sb.Append("N/A");
                        sb.Append("</th>");
                        sb.Append("</tr>");

                    }
                }



                switch (dtipopregunta)
                {

                    case "Abier":
                        sb.Append("<tr>");
                        sb.Append("<td><span>" + dtexto + "</span></td>");
                        sb.Append("</tr>");
                        sb.Append("<tr><td></td></tr> ");
                        break;

                    case "Calif":
                        sb.Append("<tr><td>");
                        if (didioma == "E")
                        { sb.Append("<span>" + drespuesta + "</span></td>"); }
                        else
                        { sb.Append("<span>" + drespuestaing + "</span></td>"); }
                        for (int i = 1; i <= dcalifmax + 1; i++)
                        {
                            if (int.Parse(dcalificacion) == i || dcalificacion == "0")
                            {
                                sb.Append("<td align=\"center\">");
                                sb.Append("<input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + "#" + i.ToString() + " name=\"Rad" + dnopregunta + dnorespuesta + "\" type=\"radio\" checked />");
                                sb.Append("</td>");
                            }
                            else
                            {
                                sb.Append("<td align=\"center\">");
                                sb.Append("<input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + "#" + i.ToString() + " name=\"Rad" + dnopregunta + dnorespuesta + "\" type=\"radio\" />");
                                sb.Append("</td>");
                            }
                        }

                        break;

                    case "Opcio":
                        sb.Append("<tr>");
                        if (!drespabierta)
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td><input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + " name=\"Rad" + dnopregunta + "\" type=\"radio\" checked/>&nbsp<span>" + drespuesta+ "</span></td>"); }
                                else
                                { sb.Append("<td><input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + " name=\"Rad" + dnopregunta + "\" type=\"radio\" checked/>&nbsp<span>" + drespuestaing + "</span></td>"); }                                
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                if (didioma == "E")
                                { sb.Append("<td><input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + " name=\"Rad" + dnopregunta + "\" type=\"radio\" />&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td><input id = " + dtipopregunta + dnopregunta + "_" + dnorespuesta + " name=\"Rad" + dnopregunta + "\" type=\"radio\" />&nbsp<span>" +  drespuestaing + "</span></td>"); }                                
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        else
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td><span>" + drespuesta + " : " + dtexto + "</span></td>"); }
                                else
                                { sb.Append("<td><span>" + drespuestaing + " : " + dtexto + "</span></td>"); }                                
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                sb.Append("<td></td>");
                                sb.Append("<tr><td></td></tr> ");
                            }

                        }
                        sb.Append("</tr>");
                        break;

                    case "Selec":
                        sb.Append("<tr>");
                        if (!drespabierta)
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                { sb.Append("<td><input id=" + dtipopregunta + dnopregunta + "_" + dnorespuesta + " type=\"checkbox\" checked />&nbsp<span>" + drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td><input id=" + dtipopregunta + dnopregunta + "_" + dnorespuesta + " type=\"checkbox\" checked />&nbsp<span>" + drespuestaing + "</span></td>"); }                                
                                sb.Append("</tr>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                if (didioma == "E")
                                { sb.Append("<td><input id=" + dtipopregunta + dnopregunta + "_" + dnorespuesta + " type=\"checkbox\" />&nbsp<span>" +  drespuesta + "</span></td>"); }
                                else
                                { sb.Append("<td><input id=" + dtipopregunta + dnopregunta + "_" + dnorespuesta + " type=\"checkbox\" />&nbsp<span>" + drespuestaing + "</span></td>"); }                                
                                sb.Append("</tr>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        else
                        {
                            if (dnorespuesta == dnorespuestaHuesped)
                            {
                                if (didioma == "E")
                                {sb.Append("<td><span>" + drespuesta + " : " + dtexto + "</span></td>"); }
                                else
                                { sb.Append("<td><span>" + drespuestaing + " : " + dtexto + "</span></td>"); }                                
                                sb.Append("<tr><td></td></tr> ");
                            }
                            else
                            {
                                sb.Append("<td>&#160</td>");
                                sb.Append("<tr><td></td></tr> ");
                            }
                        }
                        break;
                }

                if (dtipopregunta == "Calif" && int.Parse(dnorespuesta) == maximo)
                    sb.Append("</tr></table></div>");

                if (int.Parse(dnorespuesta) == maximo)
                    sb.Append("<tr><td></td></tr> ");

            }

            sb.Append("</table> ");
            sb.Append("</body></html>");
            return sb.ToString();

        }

      

        private void guardaClick()
        {
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                if (cuestionario == null)
                {
                    ModelState.AddModelError("", String.Format("Folio no encontrado {0} :", pfolio.ToString()));
                    return;
                }

                cuestionario.Fecha_Click  = DateTime.UtcNow;

                if (ModelState.IsValid)
                {
                    // Save changes here
                    context.SaveChanges();

                }
            }
        }

        private void guardaFecha()
        {
            pfolio = int.Parse(Request.QueryString["id"]);

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var cuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();
                if (cuestionario == null)
                {
                    ModelState.AddModelError("", String.Format("Folio no encontrado {0} :", pfolio.ToString()));
                    return;
                }

                cuestionario.Fecha_Contestado = DateTime.UtcNow;

                if (ModelState.IsValid)
                {
                    // Save changes here
                    context.SaveChanges();

                }
            }
        }

        private void terminaSesion()
        {
            Session.Remove("scorpo");
            Session.Remove("shotel");
            Session.Remove("stipo");
            Session.Remove("sfolio");
            string script = "window.close();";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "closewindow", script, true);

        }
        private void enviaCorreo(string pbody)
        {
            Mail correo = new Mail();
            StringBuilder sb = new StringBuilder();

            int pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
            string photel = HttpContext.Current.Session["shotel"].ToString();           
            int pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                var config = (from c in context.C_Tipos_Cuestionario 
                                  where c.Corporativo == pcorpo && c.Hotel == photel && c.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario 
                                  select new
                                  {
                                      c

                                  }).SingleOrDefault();

                var mails = (from m in context.C_Correos_Cuestionario
                             where m.Corporativo == pcorpo && m.Hotel == photel && m.Tipo_Cuestionario == tipoCuestionario.Tipo_Cuestionario
                             select new
                             {
                                 m

                             }).ToList ();

                foreach (var m in mails  )
                {
                    sb.Append(m.m.Email);
                    sb.Append(";");

                }

                correo.SMTP = config.c.Servidor_SMTP;
                correo.MailFrom = config.c.Email_Saliente;
                correo.Port = int.Parse (config.c.Puerto_SMTP.ToString ());   
                correo.IsHTML = true;

              
                 
                
            }
            correo.MailTo = sb.ToString().TrimEnd (';');
            correo.sendMail("Encuesta de Satisfacción", pbody);
        }


        [System.Web.Services.WebMethod]
        public static void insRespuesta(string idrespuesta, string valor)
        {


            int pcorpo = int.Parse(HttpContext.Current.Session["scorpo"].ToString());
            string photel = HttpContext.Current.Session["shotel"].ToString();            
            int  pfolio = int.Parse(HttpContext.Current.Session["sfolio"].ToString());
            int nr = 0;
            string tp = idrespuesta.Substring(0, 5);
            int ip = idrespuesta.IndexOf("_");
            int ic = idrespuesta.IndexOf("#");
            int np = int.Parse(idrespuesta.Substring(5, ip - 5));

            if (ic < 0)
            {
                nr = int.Parse(idrespuesta.Substring(ip + 1));
            }
            else
            {
                nr = int.Parse(idrespuesta.Substring(ip + 1, ic - ip - 1));
            }

            int cal = 0;
            if (ic > 0)
                cal = int.Parse(idrespuesta.Substring(ic + 1));

            using (CuestionarioEntities context = new CuestionarioEntities())
            {
                var tipoCuestionario = context.O_Cuestionarios.Where(x => x.Id == pfolio).FirstOrDefault();

                List< O_Cuestionarios_Respuestas > respuesta = PopulateResp(pcorpo, photel, np, pfolio, nr, tp);

                if (tp == "Opcio" && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                          && a.Id == pfolio
                                          && a.No_Pregunta == np);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                }
                else if ((tp == "Calif" || tp == "Abier") && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                           && a.Id == pfolio
                                          && a.No_Pregunta == np                                         
                                          && a.No_Respuesta == nr);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                }
                else if (tp == "Selec" && respuesta.Count > 0)
                {
                    O_Cuestionarios_Respuestas respDel = context.O_Cuestionarios_Respuestas.First(a =>
                                          a.Corporativo == pcorpo
                                          && a.Hotel == photel
                                          && a.Id == pfolio
                                          && a.No_Pregunta == np                                        
                                          && a.No_Respuesta == nr);

                    context.O_Cuestionarios_Respuestas.Remove(respDel);
                    context.SaveChanges();
                    return;
                }

                O_Cuestionarios_Respuestas resp = new O_Cuestionarios_Respuestas();
                resp.Corporativo = pcorpo;
                resp.Hotel = photel;
                resp.Id = pfolio;
                resp.No_Pregunta = np;              
                resp.No_Respuesta = nr;
                resp.Calificacion = cal;
                resp.Texto = valor == "on" ? "" : valor;
                context.O_Cuestionarios_Respuestas.Add(resp);
                context.SaveChanges();
                                
            }
        }

        [System.Web.Services.WebMethod]
        public static List<O_Cuestionarios_Respuestas> PopulateResp(int pCorpo, string pHotel, int pnp, int pfolio, int pnr, string ptp)
        {
            using (CuestionarioEntities db = new CuestionarioEntities())
            {
                if (ptp == "Opcio")
                {
                    return db.O_Cuestionarios_Respuestas.Where(a => a.Corporativo == pCorpo && a.Hotel == pHotel && a.Id  == pfolio  && a.No_Pregunta == pnp ).ToList();
                }
                else
                {
                    return db.O_Cuestionarios_Respuestas.Where(a => a.Corporativo == pCorpo && a.Hotel == pHotel && a.Id == pfolio && a.No_Pregunta == pnp &&  a.No_Respuesta == pnr).ToList();
                }
            }

        }









    }
}